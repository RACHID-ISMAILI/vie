// Script général RAUN
console.log('RAUN-Rachid2025 actif');