
// Clé secrète RAUN (placeholder uniquement, ne pas exposer en production)
const OPENAI_API_KEY = "sk-...";
        