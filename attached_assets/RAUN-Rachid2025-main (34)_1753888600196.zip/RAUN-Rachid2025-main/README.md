# RAUN API

API vivante de RAUN, permettant d'étendre les fonctionnalités côté serveur.

## Pour lancer l’API localement

```bash
cd api
npm install
npm start
```

## Exposé par défaut sur : http://localhost:3000